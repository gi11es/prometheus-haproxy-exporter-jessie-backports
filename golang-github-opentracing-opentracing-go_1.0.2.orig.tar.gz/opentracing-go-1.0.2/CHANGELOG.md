Changes by Version
==================

1.1.0 (unreleased)
-------------------

- Deprecate InitGlobalTracer() in favor of SetGlobalTracer()


1.0.0 (2016-09-26)
-------------------

- This release implements OpenTracing Specification 1.0 (http://opentracing.io/spec)

