// Package eureka provides Instancer and Registrar implementations for Netflix OSS's Eureka
package eureka
