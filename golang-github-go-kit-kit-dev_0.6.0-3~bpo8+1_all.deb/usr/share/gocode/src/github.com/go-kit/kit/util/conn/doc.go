// Package conn provides utilities related to connections.
package conn
